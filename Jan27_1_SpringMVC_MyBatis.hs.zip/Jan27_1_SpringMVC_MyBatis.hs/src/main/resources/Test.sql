create table Test(
	subject varchar2(10 char) primary key,
	year varchar2(10 char) not null,
	month varchar2(10 char) not null,
	day varchar2(10 char) not null
);
select * from Test;