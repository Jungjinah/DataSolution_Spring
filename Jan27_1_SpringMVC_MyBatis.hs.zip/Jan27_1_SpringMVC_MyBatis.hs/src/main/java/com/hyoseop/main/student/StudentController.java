package com.hyoseop.main.student;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class StudentController {
	
	@Autowired
	private StudentDAO sDAO;
	
	// 등록할 때 
	@RequestMapping(value="/student.reg", method=RequestMethod.GET)
	public String reg(Student s, HttpServletRequest req) {
		sDAO.reg(s, req);	// sDAO에서 reg 갖고옴			// index 다 만들고 Controller 와서
		return "index";									//	이 부분을 보고 dao로 가야한다는 생각을 해야함!
	}
	
	// 불러올 때
	@RequestMapping(value="/student.sel", method=RequestMethod.GET)
	public String sel(HttpServletRequest req) {
		sDAO.sel(req);
		return "index";
	}
	
	
}
