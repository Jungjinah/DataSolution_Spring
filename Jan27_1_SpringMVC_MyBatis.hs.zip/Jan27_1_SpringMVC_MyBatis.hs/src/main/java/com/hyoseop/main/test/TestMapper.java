package com.hyoseop.main.test;

import java.util.List;

public interface TestMapper {
	public abstract int regTest(Test t);
	public abstract List<Test> selTest(); 
}
